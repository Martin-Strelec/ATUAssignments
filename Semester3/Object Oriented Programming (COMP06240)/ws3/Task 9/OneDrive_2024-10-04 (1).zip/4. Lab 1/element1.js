
//Immediately Invoked Function Expression to add our event listener
(function() {
    //Add an event listener so that when the button is clicked, the changeAll function is called
    //The changeAll function will change the properties of the elements on the page
    //The function is defined in the next code block

    
    document.getElementById('btn1').addEventListener('click', changeAll);
})();

function changeAll() 
{ 
  //Make sure function is being executed
  alert("In function changeAll!"); 
  
  //Declare variables and set to null 
  let myImage = null; 
  let myDiv = null; 
  let myH1 = null; 
  let myPar = null; 

 
  //Access the first image and store a reference to it in the variable myImage. 
  //Then by manipulating the variable, we can manipulate the image 
  myImage = document.getElementById('img1'); 

  //Change the opacity of the image 
 myImage.style.opacity= "0.25"; 
 myImage.style.marginLeft='150px'; 


  //Get access to the div and make two changes 


  //Get access to the H1 and make 2 different changes 

  //Get access to the paragraph and make 2 different changes again 

} 